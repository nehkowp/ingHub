doxygen Doxyfile

firefox ./out/html/index.html

clear

gcc -Wall main.c -o exe && ./exe