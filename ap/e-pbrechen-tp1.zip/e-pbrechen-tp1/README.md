## TP1 | Fonction Hello World


# Pour lancher le programme uniquement

gcc -Wall main.c -o exe && ./exe


# Pour lancher votre programme et la documentation:

sh ./tp1.sh
